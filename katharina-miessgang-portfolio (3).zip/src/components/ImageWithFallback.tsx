import React, { useState, useEffect } from 'react';
import { Image } from 'lucide-react';

interface ImageProps {
  src?: string;
  alt?: string;
  className?: string;
  fallbackText: string;
  filename: string;
  objectFit?: 'cover' | 'contain';
}

export function ImageWithFallback({ src, alt, fallbackText, filename, className, objectFit = 'cover' }: ImageProps) {
  const [error, setError] = useState(false);

  // Reset error state if src changes
  useEffect(() => {
    setError(false);
  }, [src]);

  return (
    <div className={`relative overflow-hidden bg-[#FAF9F5] border border-border-dashed flex items-center justify-center ${className || ''}`}>
      {!error && src ? (
        <img
          src={src}
          alt={alt || ''}
          onError={() => setError(true)}
          className={`w-full h-full ${objectFit === 'contain' ? 'object-contain p-2' : 'object-cover'} transition-transform duration-500 hover:scale-[1.015]`}
          referrerPolicy="no-referrer"
        />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-[#fdfcfa] border-2 border-dashed border-border-dashed/60 select-none">
          <Image className="w-8 h-8 text-pink/40 mb-3 stroke-[1.2]" />
          <span className="font-display text-lg text-pink font-semibold mb-1 leading-tight">{fallbackText}</span>
          <span className="text-xs text-muted-dark font-mono bg-cream border border-border-dashed px-3 py-1 rounded-full mt-2">
            File: {filename}
          </span>
        </div>
      )}
    </div>
  );
}

export interface ProjectSpread {
  id: string;
  title: string;
  category: string;
  year: string;
  role: string;
  description: string;
  image: string;
  filename: string;
  aspectRatio?: string;
  objectFit?: 'cover' | 'contain';
}

export interface ProjectTile {
  id: string;
  title: string;
  category: string;
  year: string;
  image: string;
  filename: string;
  link?: string;
  aspectRatio?: string;
  objectFit?: 'cover' | 'contain';
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
}

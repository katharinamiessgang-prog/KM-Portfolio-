import { ProjectSpread, ProjectTile, ServiceItem } from './types';

export const projectSpreads: ProjectSpread[] = [
  {
    id: 'on-running',
    title: 'On Running Campaign',
    category: 'Photography & Design',
    year: '2026',
    role: 'Creative Director / Photographer',
    description: 'Conceptualized, directed, and photographed a still-image campaign for On Running, from initial concept to final execution. The campaign highlights lightness and performance through a surreal, dreamlike visual — transforming the runner into a winged figure to embody the sensation of effortless movement. By merging fashion aesthetics with athletic storytelling, the campaign positions On Running as both a performance brand and a source of elevated, expressive identity.',
    image: '/RUN.jpg',
    filename: 'RUN.jpg',
    aspectRatio: 'aspect-[3/4]'
  },
  {
    id: 'that-smile',
    title: 'That Smile',
    category: 'Documentary & Design',
    year: '2026',
    role: 'Director',
    description: 'A two-minute mood reel and accompanying poster series exploring home as an emotional experience shaped through sibling relationships. Blending documentary and design, the project unfolds through poetic narration and intimate, nostalgic imagery, centered on the motif of a spontaneous smile symbolizing safety, familiarity, and belonging.',
    image: '/Moodreel Poster Katharina Miessgang-09.jpg',
    filename: 'Moodreel Poster Katharina Miessgang-09.jpg',
    aspectRatio: 'aspect-[3/4]'
  },
  {
    id: 'levis',
    title: "Republic of Levi's",
    category: 'Documentary & Design',
    year: '2026',
    role: 'Director',
    description: "Conceptualized, designed, and shot a still-image campaign for Levi's, overseeing the process from creative idea to final execution. Set against contrasting, remote landscapes — from desert to snow — the campaign visualizes the idea that no place is too far, with the recurring Levi's box becoming a symbol of connection and shared identity across environments.",
    image: '/Mockup 3 LEVIS.jpg',
    filename: 'Mockup 3 LEVIS.jpg',
    aspectRatio: 'aspect-[16/10]'
  }
];

export const projectTiles: ProjectTile[] = [
  {
    id: 'learning-to-bloom',
    title: 'Learning to Bloom Again',
    category: 'Photography',
    year: '2025',
    image: '/Portfolio Pictures BLOOMING.jpg',
    filename: 'Portfolio Pictures BLOOMING.jpg',
    aspectRatio: 'aspect-[4/3]'
  },
  {
    id: 'pulse-mdlbeast',
    title: 'Pulse — MDLBEAST',
    category: 'Branding',
    year: '2026',
    image: '/Artboard 1.png',
    filename: 'Artboard 1.png',
    aspectRatio: 'aspect-[3/4]'
  },
  {
    id: 'almabtrieb-icons',
    title: 'Almabtrieb Icons',
    category: 'Icon Design',
    year: '2026',
    image: '/FINAL POSTERS-04.jpg',
    filename: 'FINAL POSTERS-04.jpg or the cow-icon grid image',
    aspectRatio: 'aspect-[4/3]'
  },
  {
    id: 'spiders-fear',
    title: 'Spiders: Behind the Fear',
    category: 'Infographic Design',
    year: '2026',
    image: '/Infographics.jpg',
    filename: 'Infographics.jpg',
    aspectRatio: 'aspect-[3/4]'
  },
  {
    id: 'bad-taste-mag',
    title: 'Bad Taste Magazine',
    category: 'Editorial Design (The Anatomy of a Bad Date)',
    year: '2026',
    image: '/BAD TASTE MAGAZINE 1.jpg',
    filename: 'BAD TASTE MAGAZINE 1.jpg',
    aspectRatio: 'aspect-[3/4]'
  },
  {
    id: 'magic-gum',
    title: 'Magic Gum 20',
    category: 'Advertising Film',
    year: '2026',
    image: '/Screenshot 2026-06-01 at 17.20.58.png',
    filename: 'Screenshot 2026-06-01 at 17.20.58.png',
    link: 'https://youtu.be/3xV0B75oLiI',
    aspectRatio: 'aspect-[16/9]'
  }
];

export const serviceItems: ServiceItem[] = [
  {
    id: 'cd',
    title: 'Creative direction',
    description: 'Concept to execution'
  },
  {
    id: 'photo',
    title: 'Photography',
    description: 'Campaign & editorial'
  },
  {
    id: 'brand',
    title: 'Branding',
    description: 'Identity systems'
  },
  {
    id: 'content',
    title: 'Content',
    description: 'Social & digital'
  }
];

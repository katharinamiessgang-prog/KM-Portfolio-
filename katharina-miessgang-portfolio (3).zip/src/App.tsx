import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Linkedin, Instagram, ArrowDown, MapPin, Play, ExternalLink, Menu, X } from 'lucide-react';
import { projectSpreads, projectTiles, serviceItems } from './data';
import { ImageWithFallback } from './components/ImageWithFallback';

export default function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Monitor scroll position to update the active nav link
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['about', 'work', 'services', 'contact'];
      const scrollPosition = window.scrollY + 120; // offset for nav

      // Check if near top for hero
      if (window.scrollY < 200) {
        setActiveSection('hero');
        return;
      }

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else if (id === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-cream text-ink font-sans antialiased selection:bg-pink/20 selection:text-pink">
      {/* 1. NAVIGATION BAR */}
      <nav id="nav" className="sticky top-0 z-50 bg-cream/90 backdrop-blur-md border-b border-dashed border-border-dashed transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
          <button 
            onClick={() => scrollToSection('hero')}
            className="font-display font-extrabold text-xl md:text-2xl tracking-wider hover:text-pink transition-colors focus:outline-none cursor-pointer"
          >
            KATHARINA MIESSGANG
          </button>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center space-x-10">
            {['about', 'work', 'services'].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className={`font-medium uppercase tracking-wider text-sm transition-colors relative py-2 focus:outline-none cursor-pointer ${
                  activeSection === section ? 'text-pink' : 'text-ink/70 hover:text-pink'
                }`}
              >
                {section}
                {activeSection === section && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-pink"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
            
            {/* Say Hi Button (Pill shape with soft pastel fill) */}
            <button
              onClick={() => scrollToSection('contact')}
              className="bg-pink/10 hover:bg-pink/20 text-pink border border-pink/30 hover:border-pink/40 rounded-full px-6 py-2 text-sm font-semibold tracking-wide transition-all duration-200 transform hover:scale-[1.03] cursor-pointer"
            >
              Say Hi
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-ink hover:text-pink transition-colors p-2 focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Dropdown */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="md:hidden border-b border-dashed border-border-dashed bg-cream overflow-hidden"
            >
              <div className="px-6 py-6 flex flex-col space-y-4">
                {['about', 'work', 'services'].map((section) => (
                  <button
                    key={section}
                    onClick={() => scrollToSection(section)}
                    className={`text-left font-medium uppercase tracking-wider text-base py-2 focus:outline-none cursor-pointer ${
                      activeSection === section ? 'text-pink' : 'text-ink/70'
                    }`}
                  >
                    {section}
                  </button>
                ))}
                <button
                  onClick={() => scrollToSection('contact')}
                  className="bg-pink/10 hover:bg-pink/20 text-pink border border-pink/30 hover:border-pink/40 rounded-full py-2.5 text-center text-sm font-semibold tracking-wide transition-all cursor-pointer w-full"
                >
                  Say Hi
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* MAIN CONTAINER */}
      <main className="overflow-x-hidden">
        
        {/* 2. HERO SECTION */}
        <section id="hero" className="relative min-h-[calc(100vh-80px)] flex items-center py-16 md:py-24 px-6 md:px-12 max-w-7xl mx-auto">
          <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Left Content Column */}
            <div className="lg:col-span-7 flex flex-col justify-center order-2 lg:order-1">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h1 className="font-display text-pink text-7xl sm:text-8xl md:text-9xl font-black tracking-tighter leading-none mb-6 select-none">
                  PORTFOLIO
                </h1>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.15 }}
                className="max-w-xl"
              >
                <p className="font-sans text-xl sm:text-2xl text-ink leading-relaxed font-normal mb-10">
                  Hi, I'm Katharina — Austrian creative director, digital designer & content creator based in Madrid. I turn ideas into things people stop scrolling for.
                </p>

                {/* Keep Scrolling Dashed Tag */}
                <div className="inline-flex items-center space-x-3">
                  <button
                    onClick={() => scrollToSection('about')}
                    className="border border-dashed border-border-dashed hover:border-pink/50 text-muted-dark hover:text-pink rounded-full px-5 py-2.5 font-mono text-xs uppercase tracking-widest flex items-center space-x-2 transition-all duration-300 hover:scale-[1.02] cursor-pointer"
                  >
                    <span>Keep Scrolling</span>
                    <ArrowDown className="w-3.5 h-3.5 stroke-[1.8] animate-bounce" />
                  </button>
                  <span className="font-hand text-pink text-2xl tracking-wide select-none hidden sm:inline-block ml-2">
                    based in Madrid!
                  </span>
                </div>
              </motion.div>
            </div>

            {/* Right Image Column (Asymmetric / straight-edged visual) */}
            <div className="lg:col-span-5 flex justify-center lg:justify-end order-1 lg:order-2">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7, delay: 0.1 }}
                className="w-full max-w-sm md:max-w-md"
              >
                {/* Real Image: 240724_KATHI0416.jpg styled with white border and flat solid shadow */}
                <ImageWithFallback
                  src="/240724_KATHI0416.jpg"
                  alt="Katharina Miessgang Portrait"
                  fallbackText="Katharina Miessgang Portrait"
                  filename="240724_KATHI0416.jpg"
                  className="w-full aspect-[3/4] border-[12px] border-white shadow-flat-dark"
                />
              </motion.div>
            </div>
          </div>
        </section>

        {/* SECTION DIVIDER */}
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="border-t border-dashed border-border-dashed" />
        </div>

        {/* 3. ABOUT SECTION */}
        <section id="about" className="py-24 md:py-32 px-6 md:px-12 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Left Label Column */}
            <div className="lg:col-span-3">
              <span className="font-mono text-xs uppercase tracking-widest text-pink font-bold border-b border-dashed border-pink/30 pb-1.5 inline-block">
                ABOUT
              </span>
            </div>

            {/* Right Main Content Column */}
            <div className="lg:col-span-9 space-y-10">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.6 }}
                className="font-display italic text-3xl sm:text-4xl md:text-5xl text-ink leading-tight tracking-tight font-medium"
              >
                "I create visually driven concepts that combine storytelling, branding and culture to build engaging audience experiences."
              </motion.h2>

              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="font-sans text-lg sm:text-xl text-muted-dark leading-relaxed font-normal max-w-3xl"
              >
                My work ranges from creative direction and content production to campaign conceptualization across digital, social and visual platforms — always balancing aesthetics with emotional impact and audience connection. Inspired by fashion, music, entertainment and everyday human experience.
              </motion.p>

              {/* Three Pill Tags in alternating colors */}
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="flex flex-wrap gap-3.5 pt-4"
              >
                {/* Tag 1: Madrid ES (Pink Soft Fill) */}
                <span className="bg-pink/10 text-pink border border-pink/20 rounded-full px-5 py-2 text-sm font-semibold tracking-wide">
                  Madrid, ES
                </span>

                {/* Tag 2: Austrian (Sage Soft Fill) */}
                <span className="bg-sage/15 text-[#2C5E3D] border border-sage/30 rounded-full px-5 py-2 text-sm font-semibold tracking-wide">
                  Austrian
                </span>

                {/* Tag 3: DE / EN / FR / ES (Yellow Soft Fill) */}
                <span className="bg-yellow/30 text-[#6B5A1A] border border-yellow/40 rounded-full px-5 py-2 text-sm font-semibold tracking-wide">
                  DE / EN / FR / ES
                </span>
              </motion.div>
            </div>
          </div>
        </section>

        {/* SECTION DIVIDER */}
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="border-t border-dashed border-border-dashed" />
        </div>

        {/* 4. SELECTED WORK SECTION */}
        <section id="work" className="py-24 md:py-32 px-6 md:px-12 max-w-7xl mx-auto">
          {/* Label & Header */}
          <div className="flex items-center justify-between mb-16 md:mb-24">
            <span className="font-mono text-xs uppercase tracking-widest text-pink font-bold border-b border-dashed border-pink/30 pb-1.5 inline-block">
              SELECTED WORK
            </span>
          </div>

          {/* Three Alternating Spreads */}
          <div className="space-y-32 md:space-y-48 mb-32 md:mb-48">
            {projectSpreads.map((project, index) => {
              const isEven = index % 2 === 0;
              return (
                <div 
                  key={project.id} 
                  className={`grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-16 items-center ${
                    isEven ? '' : 'lg:flex-row-reverse'
                  }`}
                >
                  {/* Image Div */}
                  <div className={`lg:col-span-7 ${isEven ? 'order-1' : 'order-1 lg:order-2'}`}>
                    <motion.div
                      initial={{ opacity: 0, y: 30 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-100px' }}
                      transition={{ duration: 0.6 }}
                    >
                      {/* Image styled with flat offset shadow and thick white border */}
                      <ImageWithFallback
                        src={project.image}
                        alt={project.title}
                        fallbackText={project.title}
                        filename={project.filename}
                        objectFit={project.objectFit || 'cover'}
                        className={`w-full ${project.aspectRatio || 'aspect-[4/3] sm:aspect-[16/10]'} ${
                          project.aspectRatio && project.aspectRatio.includes('3/4') 
                            ? 'max-w-md mx-auto md:max-w-lg lg:max-w-xl' 
                            : ''
                        } border-8 sm:border-[12px] border-white shadow-flat-dark`}
                      />
                    </motion.div>
                  </div>

                  {/* Text details Div */}
                  <div className={`lg:col-span-5 ${isEven ? 'order-2' : 'order-2 lg:order-1'}`}>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-100px' }}
                      transition={{ duration: 0.6, delay: 0.15 }}
                      className="space-y-5"
                    >
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="font-mono text-xs text-muted-dark uppercase tracking-widest">
                          {project.category} · {project.year}
                        </span>
                        <span className="font-mono text-[10px] text-pink border border-pink/25 rounded-full px-2.5 py-0.5 bg-pink/5 font-semibold tracking-wide uppercase">
                          {project.role}
                        </span>
                      </div>

                      <h3 className="font-display text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-ink leading-tight">
                        {project.title}
                      </h3>

                      <p className="font-sans text-base sm:text-lg text-muted-dark leading-relaxed">
                        {project.description}
                      </p>
                    </motion.div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Grid Divider & "EXPLORE MORE WORK" */}
          <div className="border-t border-dashed border-border-dashed pt-20 mb-12">
            <span className="font-mono text-xs uppercase tracking-widest text-pink font-bold border-b border-dashed border-pink/30 pb-1.5 inline-block">
              EXPLORE MORE WORK
            </span>
          </div>

          {/* Project Tiles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-12">
            {projectTiles.map((tile) => (
              <motion.div
                key={tile.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5 }}
                className="group flex flex-col h-full"
              >
                {/* Image card wrapper */}
                {tile.link ? (
                  <a 
                    href={tile.link} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className={`relative block w-full ${tile.aspectRatio || 'aspect-square'} border-[8px] border-white shadow-flat-dark group-hover:shadow-flat-pink transition-all duration-300 overflow-hidden cursor-pointer`}
                  >
                    <ImageWithFallback
                      src={tile.image}
                      alt={tile.title}
                      fallbackText={tile.title}
                      filename={tile.filename}
                      objectFit={tile.objectFit || 'cover'}
                      className="w-full h-full"
                    />
                    
                    {/* Video Overlay */}
                    <div className="absolute inset-0 bg-navy/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="bg-pink text-white rounded-full p-4 transform scale-90 group-hover:scale-100 transition-transform duration-300 shadow-lg">
                        <Play className="w-6 h-6 fill-white ml-0.5" />
                      </div>
                    </div>
                    
                    <div className="absolute bottom-3 right-3 bg-cream/90 text-pink border border-pink/20 rounded-full px-3 py-1 font-mono text-[10px] tracking-wider uppercase flex items-center space-x-1 backdrop-blur-sm shadow-sm">
                      <span>Video</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </div>
                  </a>
                ) : (
                  <div className={`w-full ${tile.aspectRatio || 'aspect-square'} border-[8px] border-white shadow-flat-dark hover:shadow-flat-pink transition-all duration-300`}>
                    <ImageWithFallback
                      src={tile.image}
                      alt={tile.title}
                      fallbackText={tile.title}
                      filename={tile.filename}
                      objectFit={tile.objectFit || 'cover'}
                      className="w-full h-full"
                    />
                  </div>
                )}

                {/* Metadata content */}
                <div className="mt-5 flex-grow flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h4 className="font-display text-xl font-bold text-ink group-hover:text-pink transition-colors leading-snug">
                        {tile.title}
                      </h4>
                      {tile.link && (
                        <ExternalLink className="w-4 h-4 text-pink/50 group-hover:text-pink transition-colors mt-1 flex-shrink-0" />
                      )}
                    </div>
                    <p className="font-mono text-xs text-muted-dark uppercase tracking-wide mt-1.5">
                      {tile.category} · {tile.year}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 5. SERVICES SECTION (Full-Width Navy Background) */}
        <section id="services" className="bg-navy text-cream py-24 md:py-32">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <span className="font-mono text-xs uppercase tracking-widest text-sage font-bold border-b border-dashed border-sage/30 pb-1.5 inline-block mb-16">
              SERVICES
            </span>

            {/* 4-Column Layout with Dashed Dividers */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0 border-t border-b border-dashed border-white/10">
              {serviceItems.map((service, index) => {
                return (
                  <div 
                    key={service.id} 
                    className={`py-12 px-2 md:px-6 flex flex-col justify-between h-64 border-b md:border-b-0 border-dashed border-white/10 ${
                      index > 0 ? 'lg:border-l border-dashed border-white/10' : ''
                    } ${
                      index === 2 ? 'md:border-l border-dashed border-white/10 lg:border-l' : ''
                    }`}
                  >
                    {/* Index Number */}
                    <span className="font-display text-pink font-black text-xl tracking-wide select-none">
                      0{index + 1}
                    </span>

                    {/* Content */}
                    <div className="space-y-3">
                      <h3 className="font-display text-2xl font-bold text-cream">
                        {service.title}
                      </h3>
                      <p className="font-sans text-sm text-muted-light leading-relaxed">
                        {service.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* 6. CONTACT SECTION (Centered Cream Background) */}
        <section id="contact" className="py-24 md:py-36 px-6 md:px-12 bg-cream text-ink">
          <div className="max-w-4xl mx-auto text-center flex flex-col items-center">
            
            {/* Label */}
            <span className="font-mono text-xs uppercase tracking-widest text-pink font-bold border-b border-dashed border-pink/30 pb-1.5 inline-block mb-8">
              LET'S WORK TOGETHER
            </span>

            {/* Rare Handwritten Accent Momement using Gochi Hand */}
            <motion.p 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="font-hand text-pink text-3xl sm:text-4xl mb-4 select-none"
            >
              drop me a line!
            </motion.p>

            {/* Massive Heading Email */}
            <motion.a 
              href="mailto:katharina.miessgang@alumni.ie.edu"
              className="font-display font-semibold text-2xl sm:text-4xl md:text-5xl lg:text-6xl text-ink hover:text-pink transition-all break-all underline decoration-dashed decoration-2 underline-offset-[12px] decoration-pink/40 hover:decoration-pink inline-block mb-16 cursor-pointer"
              whileHover={{ scale: 1.01 }}
            >
              katharina.miessgang@alumni.ie.edu
            </motion.a>

            {/* Horizontal LineDivider */}
            <div className="w-full border-t border-dashed border-border-dashed mb-10" />

            {/* Social and Location Links Row */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
              {/* Madrid Location */}
              <div className="flex items-center space-x-2 text-muted-dark border border-dashed border-border-dashed rounded-full px-5 py-2 bg-white/40 text-sm font-medium shadow-sm">
                <MapPin className="w-4 h-4 text-pink/70" />
                <span>Madrid</span>
              </div>

              {/* LinkedIn */}
              <a 
                href="https://www.linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-[#0077B5] hover:text-[#0077B5]/80 bg-[#0077B5]/5 border border-[#0077B5]/20 rounded-full px-5 py-2 text-sm font-semibold transition-all transform hover:scale-105 shadow-sm cursor-pointer"
              >
                <Linkedin className="w-4 h-4" />
                <span>LinkedIn</span>
              </a>

              {/* Instagram */}
              <a 
                href="https://www.instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-[#E1306C] hover:text-[#E1306C]/80 bg-[#E1306C]/5 border border-[#E1306C]/20 rounded-full px-5 py-2 text-sm font-semibold transition-all transform hover:scale-105 shadow-sm cursor-pointer"
              >
                <Instagram className="w-4 h-4" />
                <span>Instagram</span>
              </a>
            </div>

            {/* Simple footer note */}
            <p className="text-xs text-muted-light font-mono mt-16 select-none">
              &copy; 2026 Katharina Miessgang · Madrid ES
            </p>

          </div>
        </section>

      </main>
    </div>
  );
}
